Blockly.defineBlocksWithJsonArray(
[{
  "type": "bservo",
  "message0": "Bettle %1 set angle %2 °",
  "args0": [
    {
      "type": "field_dropdown",
      "name": "pin",
      "options": [
        [
          "Servo 1 ",
          "16"
        ],
        [
          "Servo 2",
          "17"
        ]
      ]
    },
    {
      "type": "input_value",
      "name": "angle",
      "check": "Number"
    }
  ],
  "inputsInline": true,
  "previousStatement": null,
  "nextStatement": null,
  "colour": "#0271D9",
  "tooltip": "",
  "helpUrl": ""
}]
);
