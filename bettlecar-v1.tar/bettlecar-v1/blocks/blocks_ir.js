Blockly.defineBlocksWithJsonArray([
    {
        "type": "ir_read",
        "message0": "IR Remote read code",
        "args0": [ ],
        "output": "Number",
        "colour": "#E67E22",
        "tooltip": "Get data from Remote Control",
        "helpUrl": ""
      }
]);